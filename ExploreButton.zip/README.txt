This is a branch of the Javascript Chapter that include the Explore button. Click on the explore button to save the text of the figure and load solveExer.html with the saved text.

The system is not perfect, but the framework is there. For instance, currently users can not change things like variable names by clicking on them. This is due to the fact that the classes we use to catch clicks are not being added in to the figures.

The files that were changed:
	Numbering.js - adds the explore button to figure descriptions
	JSeditor.js
	JSFigure.js
	javascriptControl3.html
	javascriptInput.html

